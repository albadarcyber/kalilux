# -*- coding: utf-8 -*-
import os
import sys
import platform
import time
import base64

g = "\033[32;1m"
gt = "\033[0;32m"
bt = "\033[34;1m"
b = "\033[36;1m"
m = "\033[31;1m"
c = "\033[0m"
p = "\033[37;1m"
u = "\033[35;1m"
M = "\033[3;1m"
k = "\033[33;1m"
kt = "\033[0;33m"
a = "\033[30;1m"

W = '\x1b[0m'
R = '\x1b[31m'
G = '\x1b[1;32m'
O = '\x1b[33m'
B = '\x1b[34m'
P = '\x1b[35m'
C = '\x1b[36m'
GR = '\x1b[37m'



def slowprints(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(2.0/90)
def lodprint(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(7.0/90)

semut=(gt+"""
 ###########################################
    _    _ _               _
   / \  | | |__   __ _  __| | __ _ _ __
  / _ \ | | '_ \ / _` |/ _` |/ _` | '__|
 / ___ \| | |_) | (_| | (_| | (_| | |
/_/   \_\_|_.__/ \__,_|\__,_|\__,_|_|
############################################
""")
l="Albadar Cyber.."

def main_menu():
    clear()
    slowprints(semut)
    print(p+
        "   Pilih Menu Yang Di Inginkan" +
        "\nPilih Salah Satu:"
        "\n  [1] Tembak Paket XL" + 
        "\n  [2] Phising" +
        "\n  [3] Spammer" +
        "\n  [4} Brute Force" +
        "\n  [5] Virus Generator" +
        "\n  [6] Bot"
    )
    choice = str(input(" albadarcyber==> "))
    exec_menu(choice)
    return

def exec_menu(choice):
    clear()
    if(choice == ''):
        menu_actions['main']()
    else:
        try:
            menu_actions[choice]()
        except KeyError:
            print("Invalid selection, please try again.\n")
            menu_actions['main']()
    return

def menu_1():
       slowprint("Albadar Cyber")
       os.system('cd xlotp;python app.py')
def menu_2():
       slowprint("Albadar Cyber")
       os.system('cd virus;python virus.py')
def exit():
    sys.exit()

def clear():
    return os.system("cls") if (platform.system() == 'Windows') else os.system("clear")

menu_actions = {
    "main" : main_menu,
    "1" : menu_1,
    "2" : menu_2,
    "0" : exit
}


if __name__ == "__main__":
    main_menu()
